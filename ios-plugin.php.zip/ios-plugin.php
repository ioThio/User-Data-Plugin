<?php

/***
 * Plugin Name: Io's Plugin
 * Description: Displays registered User's Username, Email, Group Name, Website and Biographical Info.
 * Version: 1.0
 * Requires at least: 5.6
 * Author: Ioanna Theofilakou
 * Author URI: https://istos.art
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ios-plugin
 * Domain Path: /languages
 */

 /*
Io's Plugin is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.

Io's PLugin is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Io's Plugin. If not, see https://www.gnu.org/licenses/gpl-2.0.html.
*/


if( ! defined( 'ABSPATH' )){
    exit;
}

function our_users_list() {
    
    $user_query = new WP_User_Query( array( 'orderby' => 'registered' ) );
    $results = $user_query->get_results();

    // no results
    if (empty($results)) {
        return 'No Users Found';
    }
	
    // when we have results
    ob_start();
	echo '<h4>Registered Users</h4>';
    echo '<ul>';
    foreach ($results as $item) {
    ?>
        <li>
            <?php echo get_avatar($item->user_email, 80); ?>
            <a href="<?php echo get_author_posts_url($item->ID); ?>"><?php echo esc_html($item->display_name); ?></a><br />
            <h5>User Email:</h5>
			<?php echo esc_html($item->user_email); ?><br />
			<h5>User Group Name:</h5>
			<?php echo esc_html($item->roles[0]); ?><br />
			<h5>Website:</h5>
			<?php if($item->user_url == null){
                echo "https://google.com";
            }else{
            echo esc_html($item->user_url);} ?><br />
			<h5>User Biographical Info:</h5>
			<?php echo wp_trim_words($item->description, 20); ?><br />
        </li>
    <?php
    }
    echo '</ul>';
    return ob_get_clean();
}

add_shortcode('list_users', 'our_users_list');

